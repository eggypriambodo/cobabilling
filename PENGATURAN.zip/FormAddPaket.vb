﻿Imports MySql.Data.MySqlClient
Public Class FormAddPaket
    Private Sub btnTambahPaket_Click(sender As Object, e As EventArgs) Handles btnTambahPaket.Click
        If ValidateInputs() Then
            tambahPaket()
            Close()
        Else
            MessageBox.Show("Pastikan semua kolom terisi dengan benar!", "Validasi Gagal", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End If
    End Sub

    Private Function ValidateInputs() As Boolean
        Dim allInputsValid As Boolean = True

        ' Validasi setiap TextBox
        allInputsValid = allInputsValid And ValidateTextBox(tbNamaPaket)
        allInputsValid = allInputsValid And ValidateTextBox(tbHarga)
        allInputsValid = allInputsValid And ValidateTextBox(tbDurasi)
        allInputsValid = allInputsValid And ValidateTextBox(tbDiscTable)

        Return allInputsValid
    End Function

    Private Function ValidateTextBox(textBox As TextBox) As Boolean
        If String.IsNullOrWhiteSpace(textBox.Text) Then
            Return False
        End If
        Return True
    End Function

    Sub tambahPaket()
        Try
            connect()
            DA = New MySqlDataAdapter("SELECT * FROM tb_daftarpaket", Koneksi)
            DT = New DataTable
            DA.Fill(DT)

            For Each row As DataRow In DT.Rows
                CMD = New MySqlCommand("INSERT INTO tb_daftarpaket (nama_paket, jenis_paket, harga_paket, durasi, disc_table) VALUES (@nama_paket, 'PAKET', @harga_paket, @durasi, @disc_table)", Koneksi)
                ' Ganti @value1, @value2, @value3 dengan nama kolom yang sesuai
                CMD.Parameters.AddWithValue("@nama_paket", row("nama_paket"))
                CMD.Parameters.AddWithValue("@harga_paket", row("harga_paket"))
                CMD.Parameters.AddWithValue("@durasi", row("durasi"))
                CMD.Parameters.AddWithValue("@disc_table", row("disc_table"))
                CMD.ExecuteNonQuery()
            Next
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally

            disconnect()

        End Try
    End Sub

End Class