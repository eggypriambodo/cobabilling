﻿Public Class FormPengaturan

    Private Sub btnTambahPromo_Click(sender As Object, e As EventArgs) Handles btnTambahPromo.Click
        FormAddPaket.Show()
    End Sub

    Private Sub btnTambahLos_Click(sender As Object, e As EventArgs) Handles btnTambahLos.Click
        FormAddLosTime.Show()
    End Sub
    Private Sub btnTambahDurasi_Click(sender As Object, e As EventArgs) Handles btnTambahDurasi.Click
        FormAddDurasi.Show()
    End Sub
End Class